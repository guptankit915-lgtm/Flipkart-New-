FLIPKART NEW — FREE WEBSITE STARTER

Included:
- index.html with 24 sample products, sample prices, online product photos, category filters, search, cart and demo checkout.

Publish free using GitHub Pages:
1. Sign in at https://github.com
2. Create a new PUBLIC repository named flipkart-new (if available).
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment choose Deploy from a branch.
6. Choose branch main and folder /(root), then Save.
7. Wait a few minutes. Your public site address will appear in Settings > Pages.

Important:
- Prices and ratings are illustrative, not current offers or real stock.
- Product photos load from Unsplash over the internet.
- Cart is stored in the visitor's browser. No real orders or payments are processed.
- Real customer login, order database and payments need a secure backend.
- “Flipkart New” may cause brand/trademark confusion. Check legal availability; an original brand name is safer before public launch.
